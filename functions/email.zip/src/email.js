
const sgMail = require('@sendgrid/mail')

sgMail.setApiKey(process.env.SENDGRID_API_KEY)

// Docs on event and context https://www.netlify.com/docs/functions/#the-handler-method
const handler = async (event) => {
  try {
    const body = JSON.parse(event.body);

    const msg = {
      to: 'nolestock@gmail.com', // Change to your recipient
      from: body.from_email, // Change to your verified sender
      subject: body.subject,
      text: body.message,
      html: '<strong>and easy to do anywhere, even with Node.js</strong>',
    }

    sgMail
    .send(msg)
    .then(() => {
      console.log('Email sent')
      return {
        statusCode: 200,
        body: JSON.stringify({ templateParams}),
      };
    })
    .catch((error) => {
      console.error(error)
    })

  } catch (error) {
    return { statusCode: 500, body: error.toString() };
  }
};

module.exports = { handler };
